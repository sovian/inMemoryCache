﻿using System;

namespace NordStromCodingExercise
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter cache capacity");
            string input = Console.ReadLine();
            int size;
            Int32.TryParse(input, out size);
            LRUCache cache = new LRUCache();
            cache.Create(size);
            for (int i = 0; i < size; i++)
            {
                cache.Add(i, size - i % 2);
            }

            cache.Get(4);
            cache.Exists(3);

        }
            
    }
}
