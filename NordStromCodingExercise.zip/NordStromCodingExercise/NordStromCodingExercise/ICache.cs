﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordStromCodingExercise
{
	public interface ICache
	{
		// return the value if key exists in cache, or -1 if not. 
		int Get(int key);
		//create new cache and initialize it
		void Create(int capacity);
		// add a new data entry to cache
		void Add(int key, int value);
		bool Exists(int key);
	}
}
