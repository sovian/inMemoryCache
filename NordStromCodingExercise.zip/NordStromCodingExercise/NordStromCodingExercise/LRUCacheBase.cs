﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordStromCodingExercise
{
    class LRUCacheBase
    {
		private int capacity;
		private int count;
		Dictionary<object, object> map;
		LRUDoubleLinkedList lruList;
		public void Create(int capacity)
		{
			this.capacity = capacity;
			this.count = 0;
			map = new Dictionary<object, object>();
			lruList = new LRUDoubleLinkedList();
		}
	}
}
