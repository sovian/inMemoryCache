﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordStromCodingExercise
{
	public class LRUCache : ICache
	{
		private int capacity;
		private int count;
		Dictionary<int, LRUNode> map;
		LRUDoubleLinkedList lruList;
		public void Create(int capacity)
		{
			this.capacity = capacity;
			this.count = 0;
			map = new Dictionary<int, LRUNode>();
			lruList = new LRUDoubleLinkedList();
		}

		// each time when access the node, we move it to the top
		public int Get(int key)
		{
			if (!map.ContainsKey(key)) return -1;
			LRUNode node = map[key];
			lruList.RemoveNode(node);
			lruList.AddToTop(node);
			return node.Value;
		}

		public bool Exists(int key)
        {
			if (map.ContainsKey(key))
			{
				LRUNode node = map[key];
				lruList.RemoveNode(node);
				lruList.AddToTop(node);
				return true;
			}
			else
				return false;
		}
		public void Add(int key, int value)
		{
			// just need to update value and move it to the top
			if (map.ContainsKey(key))
			{
				LRUNode node = map[key];
				lruList.RemoveNode(node);
				node.Value = value;
				lruList.AddToTop(node);
			}
			else
			{
				// if cache is full, then remove the least recently used node
				if (count == capacity)
				{
					LRUNode lru = lruList.RemoveLRUNode();
					map.Remove(lru.Key);
					count--;
				}

				// add a new node
				LRUNode node = new LRUNode(key, value);
				lruList.AddToTop(node);
				map[key] = node;
				count++;
			}

		}

	}
}
